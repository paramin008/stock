
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Paramin</b>
    </div>
    <strong>Copyright &copy; <?php echo date('Y') ?>.</strong> All rights reserved.
  </footer>

 
  <div class="control-sidebar-bg"></div>
</div>

</body>
</html>
